Morfologik is a project aiming at generating Polish morphosyntactic
dictionaries (hence the name) used for part-of-speech tagging and
part-of-speech synthesis.

See LICENSE.txt for license restrictions.

See README.Polish.txt for more information concerning authorship and
dictionary data format.

VERSION: 2.1 PoliMorf
BUILD:   2016-02-13 19:37:50+01:00
GIT:     6e63b53
